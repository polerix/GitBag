# #Partie A
# print("Partie A")
# from unittest.mock import Mock
# mockObj = Mock(name = "Plaise")
 
# print(mockObj)
# print (repr(mockObj))

# #partie B
# from unittest.mock import Mock
# print("\n\nPartie B")
# plaiseSpec = ["_plaiseValue", "callPlaise", "doPlaise"]
 
# # create the mock object
# mockPlaise = Mock(spec = plaiseSpec)
 
# # accessing the mocked attributes
# print(mockPlaise)
# # <Mock id='427280'>
# print(mockPlaise._plaiseValue)
# # returns <Mock name='mock._plaiseValue' id='2788112'>
# print(mockPlaise.callPlaise())
# # returns: <Mock name='mock.callPlaise()' id='2815376'>
 
# mockPlaise.callPlaise()
# # nothing happens, which is fine 

# # accessing the missing attributes
# print(mockPlaise._plaiseDjo)
# # raises: AttributeError: Mock object has no attribute '_plaiseDjo'
# mockPlaise.callPlaiseDjo()


# #partie C
# from unittest.mock import Mock
# print("\n\nPartie C")
# # The class interfaces
# class Djooe(object):
	# # instance properties
	# _DjooeValue = 55

	# def callDjooe(self):
		# print("Djooe:callDjooe_")

	# def doDjooe(self, argValue):
		# print("Djooe:doDjooe:input = ", argValue)
 
# # create the mock object
# mockDjooe = Mock(spec = Djooe)
 
# # accessing the mocked attributes
# print(mockDjooe)
# # returns <Mock spec='Djooe' id='507120'>
# print(mockDjooe._DjooeValue)
# # returns <Mock name='mock._DjooeValue' id='2788112'>
# print(mockDjooe.callDjooe())
# # returns: <Mock name='mock.callDjooe()' id='2815376'>
 
# mockDjooe.callDjooe()
# # nothing happens, which is fine
 
# # accessing the missing attributes
# print(mockDjooe._DjooeBlow)
# # raises: AttributeError: Mock object has no attribute '_DjooeBlow'
# mockDjooe.callDjooeBlow()
# # raises: AttributeError: Mock object has no attribute 'callDjooeBlow'

# #partie D
# from unittest.mock import Mock
# # create the mock object
# mockBall = Mock(return_value = "Hashtag YOLO")
 
# print (mockBall)
# #<Mock id='41731520'>
 
# mockObj = mockBall()
# print (mockObj)
# # returns: Hashtag YOLO

# #Partie E
# from unittest.mock import Mock

# class IPittyTheFoo(object):
    # # instance properties
    # _IPittyTheFooValue = "Mr.T"
     
    # def callIPittyTheFoo(self):
        # print ("IPittyTheFoo:callIPittyTheFoo_")
     
    # def doIPittyTheFoo(self, argValue):
        # print ("IPittyTheFoo:doIPittyTheFoo:input = ", argValue)
 
# # creating the mock object
# iPittyTheFooObj = IPittyTheFoo()
# print (iPittyTheFooObj)
# # returns: <__main__.IPittyTheFoo object at 0x000000000345C668>
 
# mockIPittyTheFoo = Mock(return_value = iPittyTheFooObj)
# print (mockIPittyTheFoo)
# # returns: <Mock id='58789168'>
 
# # creating an "instance"
# mockObj = mockIPittyTheFoo()
# print (mockObj)
# # returns: <__main__.IPittyTheFoo object at 0x000000000345C668>
 
# # working with the mocked instance
# print (mockObj._IPittyTheFooValue)
# # returns: Mr.T
# mockObj.callIPittyTheFoo()
# # returns: IPittyTheFoo:callIPittyTheFoo_
# mockObj.doIPittyTheFoo("I Pitty The Foo Who aint a knight Elf Mohawk")
# # returns: IPittyTheFoo:doIPittyTheFoo:input =  I Pitty The Foo Who aint a knight Elf Mohawk

#Partie F
from unittest.mock import Mock
# The mock object
class Ball(object):
    # instance properties
    _fooValue = "round"
     
    def callBall(self):
        print ("Foo:callFoo_")
     
    def doBall(self, argValue):
        print ("Foo:doBall:input = ", argValue)
 
# creating the mock object (without a side effect)
ballObj = Ball()
 
mockBall = Mock(return_value = ballObj)
print (mockBall)
# returns: <Mock id='46072888'>
 
# creating an "instance"
mockObj = mockBall()
print (mockObj)
# returns: <__main__.Ball object at 0x0000000002844208>
 
# creating a mock object (with a side effect)
 
mockBall = Mock(return_value = ballObj, side_effect = Exception)
mockObj = mockBall()
# raises: Exception

