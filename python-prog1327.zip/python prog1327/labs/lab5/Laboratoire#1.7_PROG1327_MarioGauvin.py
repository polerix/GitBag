#!/usr/bin/env python
# -*- coding: utf-8 -*-

from lxml import etree

print("Laboratoire 1.7 par Mario Gauvin")
cmd = 'y'
users_data = []
g=True
id=0
while g is True:
	if cmd in ["Y", "y"]:
		name = input("What is your name? ")
		age = input("What is your age? ")
		city = input("Which city do you live in? ")
		cmd = input("Enter another user? (Y or y) ")
		id+=1
		user=[id,name, age, city]
		users_data.append(user)
	else:
		g=False 


	
users = etree.Element("users")


for user_data in users_data:
	user = etree.SubElement(users, "user")
	user.set("id", str(user_data[0]))
	name = etree.SubElement(user, "name")
	name.text = user_data[1]
	age = etree.SubElement(user, "age")
	age.text = user_data[2]
	city = etree.SubElement(user, "city")
	city.text = user_data[3]

doc = etree.ElementTree(users)
doc.write("users.xml", xml_declaration=True, encoding='utf-16') 

input("Press Enter key to exit.")