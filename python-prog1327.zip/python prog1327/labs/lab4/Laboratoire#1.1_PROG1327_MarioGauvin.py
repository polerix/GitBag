import re
#part A
num = input("Votre nombre: ")
regex = re.compile(r"\d")
while True:
	if regex.match(num) is not None:
		print("La chaine saisie est bien un nombre...")
		break
	else:
		num = input("La chaine saisie n'est pas un nombre...")

#part B
plateNum = input("Votre imatriculation ?  ")
regex = re.compile(r"[A-Z]{3}-[0-9]{3}")
if regex.match(plateNum) is not None:
	print("\"%s\" est une plaque d'immatriculation du NB" %plateNum)
else:
	print("\"%s\" n'est pas une plaque d'immatriculation du NB" %plateNum)

#part C
ip = input("Veuillez saisir une adresse ip: ")
regex = re.compile(r"^([0-9]{1,2}|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.([0-9]{1,2}|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.([0-9]{1,2}|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.([0-9]{1,2}|1[0-9]{2}|2[0-4][0-9]|25[0-4])$")
if regex.match(ip) is not None:
	print("\"%s\" est bien une adresse IP" %ip)
else:
	print("\"%s\" n'est pas une adresse IP" %ip)
