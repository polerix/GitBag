#!/usr/bin/env python
# -*- coding: latin-1 -*-
import os
import pickle
try:
	print("Laboratoire 1.2 A par Mario Gauvin")
	user = input("Quel est votre nom? ")
	fileName = "info.txt"
	if not os.path.exists(user):
		os.mkdir(user)
	else:
	
		ville = input("Dans quelle ville demeurez-vous? ")
		phone = input("Quel est votre num�ro de t�l�phone? ")
		Fichier = open(user+"\\"+fileName, 'w')
		Fichier.write("Nom: "+ user + "\nVille: " + ville + "\nNum�ro de t�l�phone: " + phone)
		Fichier.close()
		print("Fichier Sauvgard�! ")
except IOError as e:
	print(e)

input("Appuyer la touche Enter pour sortir")

try:
	print("Laboratoire 1.2 B par Mario Gauvin")
	user = input("Quel est votre nom? ")
	fileName = "infopickle.txt"
	if not os.path.exists(user):
		os.mkdir(user)
	else:
	
		ville = input("Dans quelle ville demeurez-vous? ")
		phone = input("Quel est votre num�ro de t�l�phone? ")
		userInfo = {'name': user, 'city:': ville, 'phone': phone}
		Fichier = open(user+"\\"+fileName, 'wb')
		pickle.dump(userInfo,Fichier)
		Fichier.close()
		print("Fichier Sauvgard�! ")
		Fichier = open(user+"\\"+fileName, 'rb')
		loadUserInfo=pickle.load(Fichier)
		Fichier.close()
		print(loadUserInfo)
except IOError as e:
	print(e)

input("Appuyer la touche Enter pour sortir")