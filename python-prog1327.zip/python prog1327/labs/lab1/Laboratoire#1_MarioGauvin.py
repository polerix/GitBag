import unittest
import calculator

class CalculatorTestSuite(unittest.TestCase):
    def setUp(self):
        self.calc = calculator.Calculator()

    def tearDown(self):
        del self.calc

    def testConvertCelsiusToFahrenheit(self):
        value = self.calc.convertCelsiusToFahrenheit(100)
        self.assertEqual(value, 212)
        
        value = self.calc.convertCelsiusToFahrenheit(0)
        self.assertEqual(value, 32)
        
        value = self.calc.convertCelsiusToFahrenheit(56)
        self.assertEqual(value, 132.8)

    def testNumberOfWidgets(self):
        value = self.calc.numberOfWidgets(100,5620)
        self.assertEqual(value, 600)

        value = self.calc.numberOfWidgets(75,1915)
        self.assertEqual(value, 200)

        value = self.calc.numberOfWidgets(200,9400)
        self.assertEqual(value, 1000)

    def testConvertDollarsToPounds(self):
        value = self.calc.convertDollarsToPounds(100)
        self.assertEqual(value, 68)

        value = self.calc.convertDollarsToPounds(25)
        self.assertEqual(value, 17)

        value = self.calc.convertDollarsToPounds(1)
        self.assertEqual(value, 0.68)

    def testConvertDollarsToEuros(self):
        value = self.calc.convertDollarsToEuros(100)
        self.assertEqual(value, 83)

        value = self.calc.convertDollarsToEuros(25)
        self.assertEqual(value, 20.75)

        value = self.calc.convertDollarsToEuros(1)
        self.assertEqual(value, 0.83)

    def testConvertDollarsToYen(self):
        value = self.calc.convertDollarsToYen(100.00)
        self.assertEqual(value, 10836.00)

        value = self.calc.convertDollarsToYen(25.00)
        self.assertEqual(value, 2709.00)

        value = self.calc.convertDollarsToYen(1.00)
        self.assertEqual(value, 108.36)

    def testMonthlyCountySalesTax(self):
        value = self.calc.monthlyCountySalesTax(9500.00)
        self.assertEqual(value, 190.00)

        value = self.calc.monthlyCountySalesTax(5000.00)
        self.assertEqual(value, 100.00)

        value = self.calc.monthlyCountySalesTax(15000.00)
        self.assertEqual(value, 300.00)
        
    def testMonthlyStateSalesTax(self):
        value = self.calc.monthlyStateSalesTax(9500.00)
        self.assertEqual(value, 380.00)

        value = self.calc.monthlyStateSalesTax(5000.00)
        self.assertEqual(value, 200.00)

        value = self.calc.monthlyStateSalesTax(15000.00)
        self.assertEqual(value, 600.00)

    def testPropertyAssessmentValue(self):
        value = self.calc.propertyAssessmentValue(100000.00)
        self.assertEqual(value, 60000.00)

        value = self.calc.propertyAssessmentValue(75000.00)
        self.assertEqual(value, 45000.00)

        value = self.calc.propertyAssessmentValue(250000.00)
        self.assertEqual(value, 150000.00)

    def testPropertyTax(self):
        value = self.calc.propertyTax(100000.00)
        self.assertEqual(value, 384.00)

        value = self.calc.propertyTax(75000.00)
        self.assertEqual(value, 288.00)

        value = self.calc.propertyTax(250000.00)
        self.assertEqual(value, 960.00)
        
unittest.main()




