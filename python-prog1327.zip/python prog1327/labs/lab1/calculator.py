class Calculator():
    def convertCelsiusToFahrenheit(self, celcius):
        return round((1.8 * celcius) + 32, 2)

    def numberOfWidgets(self, palletWeight, weight):
        return round((weight - palletWeight) / 9.2, 2)

    def convertDollarsToPounds(self, dollars):
        return round(dollars * 0.68, 2)

    def convertDollarsToEuros(self, dollars):
        return round(dollars * 0.83, 2)

    def convertDollarsToYen(self, dollars):
        return round(dollars * 108.36, 2)

    def monthlyCountySalesTax(self, sales):
        return round(sales * 0.02, 2)

    def monthlyStateSalesTax(self, sales):
        return round(sales * 0.04, 2)

    def propertyAssessmentValue(self, propertyValue):
        return round(propertyValue * 0.6, 2)

    def propertyTax(self, propertyValue):
        return round((propertyValue / 100) * 0.384, 2)

