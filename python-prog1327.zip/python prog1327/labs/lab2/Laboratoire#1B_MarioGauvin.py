class Calculator():
	def convertCelsiusToFahrenheit(self, celcius):
		"""
		return round((1.8 * celcius) + 32, 2)
		>>> Calculator.convertCelsiusToFahrenheit(Calculator, 100)
		212.0
		>>> Calculator.convertCelsiusToFahrenheit(Calculator, 0)
		32.0
		>>> Calculator.convertCelsiusToFahrenheit(Calculator, 56)
		132.8
		"""
		return round((1.8 * celcius) + 32, 2)
		
	def numberOfWidgets(self, palletWeight, weight):
		"""
		>>> Calculator.numberOfWidgets(Calculator, 100,5620)
		600.0
		>>> Calculator.numberOfWidgets(Calculator, 75, 1915)
		200.0
		>>> Calculator.numberOfWidgets(Calculator, 200,9400)
		1000.0
		"""
		return round((weight - palletWeight) / 9.2, 2)

	def convertDollarsToPounds(self, dollars):
		"""
		>>> Calculator.convertDollarsToPounds(Calculator, 100)
		68.0
		>>> Calculator.convertDollarsToPounds(Calculator, 25)
		17.0
		>>> Calculator.convertDollarsToPounds(Calculator, 1)
		0.68
		"""
		return round(dollars * 0.68, 2)

	def convertDollarsToEuros(self, dollars):
		"""
		>>> Calculator.convertDollarsToEuros(Calculator, 100)
		83.0
		>>> Calculator.convertDollarsToEuros(Calculator, 25)
		20.75
		>>> Calculator.convertDollarsToEuros(Calculator, 1)
		0.83
		"""
		return round(dollars * 0.83, 2)

	def convertDollarsToYen(self, dollars):
		"""
		>>> Calculator.convertDollarsToYen(Calculator, 100.00)
		10836.0
		>>> Calculator.convertDollarsToYen(Calculator, 25.00)
		2709.0
		>>> Calculator.convertDollarsToYen(Calculator, 1.00)
		108.36
		"""
		return round(dollars * 108.36, 2)

	def monthlyCountySalesTax(self, sales):
		"""
		>>> Calculator.monthlyCountySalesTax(Calculator, 9500.00)
		190.0
		>>> Calculator.monthlyCountySalesTax(Calculator, 5000.00)
		100.0
		>>> Calculator.monthlyCountySalesTax(Calculator, 15000.00)
		300.0
		"""
		return round(sales * 0.02, 2)

	def monthlyStateSalesTax(self, sales):
		"""
		>>> Calculator.monthlyStateSalesTax(Calculator, 9500.00)
		380.0
		>>> Calculator.monthlyStateSalesTax(Calculator, 5000.00)
		200.0
		>>> Calculator.monthlyStateSalesTax(Calculator, 15000.00)
		600.0
		"""
		return round(sales * 0.04, 2)

	def propertyAssessmentValue(self, propertyValue):
		"""
		>>> Calculator.propertyAssessmentValue(Calculator, 100000.00)
		60000.0
		>>> Calculator.propertyAssessmentValue(Calculator, 75000.00)
		45000.0
		>>> Calculator.propertyAssessmentValue(Calculator, 250000.00)
		150000.0
		"""
		return round(propertyValue * 0.6, 2)

	def propertyTax(self, propertyValue):
		"""
		>>> Calculator.propertyTax(Calculator, 100000.00)
		384.0
		>>> Calculator.propertyTax(Calculator, 75000.00)
		288.0
		>>> Calculator.propertyTax(Calculator, 250000.00)
		960.0
		"""
		return round((propertyValue / 100) * 0.384, 2)

