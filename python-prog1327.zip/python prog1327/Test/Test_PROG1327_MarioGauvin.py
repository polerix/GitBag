import os
import re
from lxml import etree
print("Test par Mario Gauvin\nWelcome to my employees!\n")

cmd = ""
companyTxt = input("\nWhat is the name of your company? ")
while re.match(r"^[A-Z][a-zA-Z \.,]+$", companyTxt) is None:
	companyTxt = input("Invalid. What is the name of your company? ")

myEmployees = etree.Element("myEmployees")
myEmployees.set("name", companyTxt)
doc = etree.ElementTree(myEmployees)
while True:

	

	empNameTxt = input("\nWhat is the name of the employee? ")
	while re.match(r"^[A-Z][a-zA-Z0-9]+$", empNameTxt) is None:
		empNameTxt = input("Invalid. What is the name of the employee? ")

	empNumberTxt = input("\nWhat is his/her employee number? ")
	while re.match(r"^[0-9]{6}$", empNumberTxt) is None:
		empNumberTxt = input("Invalid. What is his/her employee number? ")

	empSalary = input("\nWhat is his salary? ")
	while re.match(r"^[0-9]{1,}\.[0-9]{2}$", empSalary) is None:
		empSalary = input("Invalid salary. What is his/her salary? ")

	empHours = input("\nHow many hours did he work? ")
	while re.match(r"^[0-9]{1,}\.[0-9]{1}$", empHours) is None:
		empHours = input("Invalid. How many hours did he/she work? ")
		
	employee = etree.SubElement(myEmployees, "employee")
	employee.set("employee-num", str(empNumberTxt))
	name = etree.SubElement(employee, "name")
	name.text = empNameTxt
	salary = etree.SubElement(employee, "salary")
	salary.text = empSalary
	hours = etree.SubElement(employee, "hours")
	hours.text = empHours
	pay = etree.SubElement(employee, "pay")
	total = float(empSalary) * float(empHours)
	pay.text = str(total)

	cmd = input("\nEnter another employee? (Y or y): ") 
	if cmd.lower() != "y":
		break

try:
	if not os.path.exists(companyTxt):
		os.mkdir(companyTxt)
	doc.write(companyTxt+"\\myEmployees.xml", xml_declaration=True, encoding='utf-16') 
	print("File Saved!")
except IOError:
	print("Error creating file!")


