import untangle
import movies
import os
import re
from lxml import etree

print("Examen par Mario Gauvin\nWelcome to my movies!")

cmd = ""

	
movieID = 1
	
myMovies = etree.Element("myMovies")
myMovies.set("name","Mario Gauvin")
doc = etree.ElementTree(myMovies)

while True:

	colNameTxt = input("\nWhat is the colletor's name? ")
	while re.match(r"^[A-Z][a-zA-Z \.,]+$", colNameTxt) is None:
		colNameTxt = input("Invalid. What is the your colletor's name? ")
		
	movieNameTxt = input("\nWhat is the name of the movie? ")
	while re.match(r"^[A-Z][a-zA-Z \.,]+$", movieNameTxt) is None:
		movieNameTxt = input("Invalid name. What is the name of the movie? ")

#[A-Z][a-zA-Z \.,]

	movieDistTxt = input("\nWho is his the distributor? ")
	while re.match(r"^[A-Z][a-zA-Z \.,]+$", movieDistTxt) is None:
		movieDistTxt = input("Invalid distributor. Who is his the distributor? ")
		
	movieLenghtTxt = input("\nWhat is the length of the movie (mins)? ")
	while re.match(r"^[0-9][0-9]+$", movieLenghtTxt) is None:
		movieLenghtTxt = input("Invalid length. What is the length of the movie (mins)?")
		
		
	movie = etree.SubElement(myMovies, "movie")
	movie.set("ID", str(movieID))
	movie.set("collector", colNameTxt)
	title = etree.SubElement(movie, "title")
	title.text = movieNameTxt
	distributor = etree.SubElement(movie, "distributor")
	distributor.text = movieDistTxt
	length = etree.SubElement(movie, "length")
	length.text = movieLenghtTxt

	movieID += 1
	cmd = input("\nEnter another movie? (Y or y): ") 
	if cmd.lower() != "y":
		break

try:
	if not os.path.exists("exam"):
		os.mkdir("exam")
	doc.write("myMovies.xml", xml_declaration=True, encoding='utf-16') 
	print("\nFile myMovies.xml created!")
except IOError:
	print("Error creating file!")
	
myMovies = movies.MyMovies()

doc = untangle.parse('myMovies.xml')

for m in doc.myMovies.movie:
	myMovies.add_movie(m['id'], m['collector'], m.title.cdata, m.distributor.cdata, m.length.cdata)
	
try:
	if not os.path.exists("MyMovies"):
		os.mkdir("MyMovies")
		
	for a in myMovies.movies: 
		collectors = a.collector
		filepath = "MyMovies\\" + a.collector
		#collector directory
		if not os.path.exists(filepath):
			os.mkdir(filepath)

		for c in collectors:
			distributor = a.distributor
			filepath = "MyMovies\\" + a.collector+"\\"+ distributor
			#distributor directory
			if not os.path.exists(filepath):
				os.mkdir(filepath)
			Fichier = open(filepath + "\\" +a.title + ".txt", 'w')
			Fichier.write("length: " + a.length + " mins.")
			Fichier.close()
			file = "MyMovies\\" + a.collector+"\\"+ distributor + "\\" + a.title + ".txt"
		print("\nFile %s Created!" %file)

except IOError:
	print("Error creating file!")

input("\nPress Enter key to exit.")
