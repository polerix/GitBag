class Movie():
    def __init__(self, id, collector, title, distributor, length):
        self.id = id
        self.collector = collector
        self.title = title
        self.distributor = distributor
        self.length = length
        
class MyMovies():
    def __init__(self):
        self.movies = []
        self.name = ""

    def add_movie(self, id, collector, title, distributor, length):
        movie = Movie(id, collector, title, distributor, length)
        self.movies.append(movie)
