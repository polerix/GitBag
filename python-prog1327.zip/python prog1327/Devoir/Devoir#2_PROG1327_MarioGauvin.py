import os
import re

print("Devoir 2 par Mario Gauvin")
print("Arborescence de fichiers")
grades = ["A+","A","B+","B","C+","C","D","F"]
cmd = ""
cours = input("\nQuel est le nom du cours? ")
while re.match(r"^[^\\\\\/\?\%\*\:\|\"<>]+$", cours) is None:
	cours = input("Nom invalide. Quel est le nom du cours? ")
while True:

	nom = input("\nQuel est le nom de l'étudiant? ")
	while re.match(r"^[A-Za-z\s\-,]+$", nom) is None:
		nom = input("Nom invalide. Quel est le nom de l'étudiant? ")
		
	note = input("Quelle est sa note? ")
	while note not in grades:
		note = input("Note invalide. Quelle est sa note? ")
		
	try:
		if not os.path.exists(cours):
			os.mkdir(cours)
		Fichier = open(cours+"\\"+nom+".txt", 'w')
		Fichier.write(note)
		Fichier.close()
		print("Fichier Sauvgardé! ")
	except IOError:
		print("Error creating file!")

	cmd = input("Voulez-vous enregistrer un autre étudiant? (O ou o) ") 
	if cmd.lower() != "o":
		break
		



input("\nAppuyer la touche Enter pour sortir.")