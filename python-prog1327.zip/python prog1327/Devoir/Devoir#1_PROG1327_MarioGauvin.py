import os
from lxml import etree
import re
print("Devoir 1 par Mario Gauvin\nWelcome to my library!\n")

i = 1
cmd = ""
library = etree.Element("library")
library.set("name", "Mario Gauvin")
doc = etree.ElementTree(library)
while True:
	titleTxt  = input("\nWhat is the title of the book? ")
	regex = re.compile(r"^[A-Za-z0-9\s\-,]+$")
	while True:
		if regex.match(titleTxt ) is not None:
			break
		else:
			titleTxt  = input("Invalid title. What is the title of the book? ")

	authorTxt  = input("Who is the author?")
	regex = re.compile(r"^[A-Z][a-zA-Z0-9]+([_ -]?[a-zA-Z0-9])*$")
	while True:
		if regex.match(authorTxt ) is not None:
			break
		else:
			authorTxt  = input("Invalid name. Who is the author? ")
		
	yearTxt = input("What year was it published? ")
	regex = re.compile(r"^[0-9]{4}$")
	while True:
		if regex.match(yearTxt ) is not None:
			break
		else:
			yearTxt  = input("Invalid Year. What year was it published? ")
		

	priceTxt  = input("What is the price of the book? ")
	regex = re.compile(r"^[0-9]+\.[0-9]{2}$")
	while True:
		if regex.match(priceTxt ) is not None:
			break
		else:
			priceTxt  = input("Invalid price. What is the price of the book? ")
		
	book = etree.SubElement(library, "book")
	book.set("id", str(i))
	title = etree.SubElement(book, "title")
	title.text = titleTxt
	author = etree.SubElement(book, "author")
	author.text = authorTxt
	year = etree.SubElement(book, "year")
	year.text = yearTxt
	price = etree.SubElement(book, "price")
	price.text = priceTxt
	
	i += 1

	cmd = input("\nEnter another book? (Y or y): ")
	if cmd.lower() != "y":
		break

try:
	user = "Mario Gauvin"
	if not os.path.exists(user):
		os.mkdir(user)
	doc.write(user+"\\mylibrary.xml", xml_declaration=True, encoding='utf-16') 
	print("File Saved!")
except IOError:
	print("Error creating file!")
	
input("\nPress Enter key to exit.")
