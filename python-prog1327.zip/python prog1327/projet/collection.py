class Collector():
	def __init__(self, id, user, email):
		self.id = id
		self.username = user
		self.email = email

class Item():
	def __init__(self, id, name, image, desc, type, brand):
		self.id = id
		self.name = name
		self.image_link = image
		self.description = desc
		self.type = type
		self.brand = brand

class Collector_Item():
	def __init__(self, id, collector_id, item_id):
		self.id = id
		self.collector_id = collector_id
		self.item_id = item_id

class Collection():
	def __init__(self):
		self.collectors = []
		self.items = []
		self.collector_items = []
		
	def add_collector(self, id, user, email):
		c = Collector(id, user, email)
		self.collectors.append(c)

	def add_item(self, id, name, image, desc, type, brand):
		i = Item(id, name, image, desc, type, brand)
		self.items.append(i)
		
	def add_collector_item(self, id, collector_id, item_id):
		ci = Collector_Item(id, collector_id, item_id)
		self.collector_items.append(ci)
		
	def return_collector_items(self, id):
		items = []
		for ci in self.collector_items:
			if ci.collector_id == id:
				items.append(ci.item_id)
		return items
		
	def return_collector_info(self, id):
		for c in self.collectors:
			if c.id == id:
				return c
	
	def return_item_info(self, id):
		for i in self.items:
			if i.id == id:
				return i
