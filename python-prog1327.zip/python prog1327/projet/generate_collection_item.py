import random
collector_item = ""
for i in range(1, 201):
	randcollectid = str(random.randint(1, 12))
	randitemid = str(random.randint(1, 55))
	collector_item += "<collector_item id='"+str(i)+"' collector_id='"+randcollectid+"' item_id='"+randitemid+"'/>\n"
file = open("generate.txt", "w")
file.write(collector_item)
file.close()