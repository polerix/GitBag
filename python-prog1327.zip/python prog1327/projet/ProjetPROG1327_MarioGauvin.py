#!/usr/bin/env python
# -*- coding: latin-1 -*-
import untangle
import collection
import os
import shutil


myCollection = collection.Collection()

doc = untangle.parse('collection.xml')

for a in doc.collection.items.item:
	myCollection.add_item(a['id'], a.name.cdata, a.image_link.cdata, a.description.cdata, a.type.cdata, a.brand.cdata)
	
for b in doc.collection.collectors.collector:
	myCollection.add_collector(b['id'], b.username.cdata, b.email.cdata)


for c in doc.collection.collector_items.collector_item:
	myCollection.add_collector_item(c['id'], c['collector_id'], c['item_id'])
	
try:
	if not os.path.exists("ProjetPROG1327_MarioGauvin_SeanMoore"):
		os.mkdir("ProjetPROG1327_MarioGauvin_SeanMoore")
		
	for b in myCollection.collectors: 
		items = myCollection.return_collector_items(b.id)
		filepath = "ProjetPROG1327_MarioGauvin_SeanMoore\\" + b.username 
		#username directory
		if not os.path.exists(filepath):
			os.mkdir(filepath)
		Fichier = open(filepath + "\\" + b.username+".txt", 'w')
		Fichier.write("id: " + b.id + "\nemail: " + b.email)
		Fichier.close()

		for i in items:
			item = myCollection.return_item_info(i)
			filepath = "ProjetPROG1327_MarioGauvin_SeanMoore\\" + b.username+"\\"+item.type
			#item type directory
			if not os.path.exists(filepath):
				os.mkdir(filepath)
				
			filepath = "ProjetPROG1327_MarioGauvin_SeanMoore\\" + b.username+"\\"+item.type+"\\"+item.brand
			#item brand directory
			if not os.path.exists(filepath):
				os.mkdir(filepath)
			Fichier = open(filepath + "\\" +item.name+".txt", 'w')
			Fichier.write("id: " + item.id + "\ndescription: " + item.description)
			Fichier.close()
			shutil.copy2(item.image_link, filepath) # complete target filename given

except IOError:
	print("Error creating file!")
shutil.make_archive("ProjetPROG1327_MarioGauvin_SeanMoore", 'zip', "ProjetPROG1327_MarioGauvin_SeanMoore")