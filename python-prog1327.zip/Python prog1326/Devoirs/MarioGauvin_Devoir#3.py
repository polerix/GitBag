import school
print("Devoir 3 par Mario Gauvin")
print("Utilisation de classe et module. Script pour calculer la moyenne d'un cours.")

def printMenu():
    print(
         "\n--------------------------------------------\n"
         +"1 - Inscrire des étudiants au cours \n"
         +"2 - Afficher la moyenne du cours \n"
         +"3 - Afficher la moyenne d'un étudiant(e) \n"
         +"4 - Afficher tous les étudiant(e)s \n"
         +"5 - Recommencez pour un nouveau cours \n"
         +"6 - sortir")



myCourse = school.Course()
course = input("\nQuel est le nom du cours? ")

while len(course) <5:
    course = input("Nom invalide. Quel est le nom du cours? ")
myCourse.courseName = course

printMenu()
cmd=''
while True:
    cmd = input("Veuillez choisir une comande: ")
    if cmd not in ["1","2","3","4","5","6"]:
        print("Commande invalide")
        
    elif cmd == "1":
        print()
        myCourse.add_students()
        
    elif cmd == "2":
        myCourse.return_course_average()

    elif cmd == "3":
        myCourse.return_student_average()

    elif cmd == "4":
        myCourse.return_all_students()
        
    elif cmd == "5":
        myCourse = school.Course()
        course = input("\nQuel est le nom du cours? ")
        while len(course) <5:
            course = input("Nom invalide. Quel est le nom du cours? ")
        myCourse.courseName = course
    elif cmd == "6":
        break
    printMenu()
input("\nAppuyer la touche Enter pour sortir.")
