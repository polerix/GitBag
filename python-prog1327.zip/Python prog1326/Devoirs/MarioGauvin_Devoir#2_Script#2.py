print("Devoir 2 Script 2 par Mario Gauvin")
print("Script pour afficher des nombres en liste et en tuple.")
nombres = input("Entrez une séquence de nombres séparés par des virgules:")

g = nombres.split(',')    
liste = g
chek=True

for a in liste:
    if a.isdigit():
       continue
    else:
        chek=False
        break

if chek==True:        
    print("Voici la liste:\n",liste)
    tup = tuple(liste)
    print("Voici le tuple:\n",tup)
else:
    print("Votre liste ne contient pas que des nombres")
    
input("Appuyer la touche Enter pour sortir.")
