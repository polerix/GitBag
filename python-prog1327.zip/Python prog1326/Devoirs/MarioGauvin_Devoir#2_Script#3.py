print("Devoir 2 Script 3 par Mario Gauvin")
print("Script pour afficher le factoriel d'un nombre.")
factoriel = 1
try:
    num = int(input("Entrer un nombre: "))
    
    if num < 0:
        print("On ne peut pas produire le factoriel d'un nombre négatif")
    elif num == 0:
        print("Le factoriel de 0 est 1")
    else:
        for i in range(1,num + 1):
            factoriel = factoriel*i
        
except:
    ValueError
    print("Ce n'est pas un entier!")
if factoriel!=1:
    print("Le factoriel de votre nombre est:",factoriel)    




   
input("Appuyer la touche Enter pour sortir.")

