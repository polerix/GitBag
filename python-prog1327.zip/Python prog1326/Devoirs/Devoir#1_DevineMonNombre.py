import random
print("Devoir 1 - Devine mon nombre par Mario Gauvin\n")

randomNumber = random.randrange(1,21)
name = input("Salut! Quel est ton nom? ")
print(name+', je pense à un nombre entre 1 et 20')
count=1
while count < 8:
    while True:
        try:
            guess = input("Essai de deviner.\n")
            if (int(guess) >= 1 and int(guess) <= 20):
                break
            except ValueError:
                print("Ce n'est pas un nombre!")


    if(count == 6):
        print("pas de chance!! Le nombre auquel je pensai était le ", randomNumber)
        break
    
    elif (int(guess) < randomNumber):
        print("Ton nombre est trop bas. ")
        count+=1
        
    elif (int(guess) > randomNumber):
        print("ton nombre est trop haut. ")
        count+=1
    
    else:
        print("Bravo "+name+"! Tu as trouvé mon nombre en ",count,"essais!")
        break
input("\nPress Enter key to exit")
