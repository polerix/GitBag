print("Devoir 2 Script 5 par Mario Gauvin")
print("Script pour afficher les nombres premiers dans une gamme définie.")
try:
    smallNum = int(input("Entrer le plus petit nombre de la gamme: "))
    bigNum = int(input("Entrer le plus grand nombre de la gamme: "))
    if smallNum < 1  or bigNum < 1:
        print("Ce n'est pas un entier positif")
        
    elif smallNum > bigNum:
        print("Vous n'avez pas entré un petit nombre en premier.")
        
    else:
       for num in range(smallNum,bigNum):
           if num > 1:
               for i in range(2,num):
                   if (num % i) == 0:
                       break                
               else:
                   print(num)
       
except:
    ValueError
    print("Ce n'est pas un entier!")
   
input("Appuyer la touche Enter pour sortir.")

