print("Devoir 2 Script 4 par Mario Gauvin")
print("Script pour déterminer si un nombre est un nombre permier.")
try:
    num = int(input("Entrer un nombre: "))
    if num < 1:
        print(num,"n'est pas un entier positif")
        
    elif num > 1:
       for i in range(2,num):
           if (num % i) == 0:
               print(num,"is not a prime number")
               print(i,"times",num//i,"is",num)
               break
       else:
            print(num,"est un nombre premier")

    else:
       print(num,"n'est pas un nombre premier")
       
except:
    ValueError
    print("Ce n'est pas un entier!")
   
input("Appuyer la touche Enter pour sortir.")

