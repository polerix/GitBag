import employee
print("Devoir 4 par Mario Gauvin")
print("Utilisation de classe et module. Script pour manipuler des employé(e)s.")

def printMenu():
    print(
         "\n--------------------------------------------\n"
         +"1 - Add employees to the directory \n"
         +"2 - Display employee salary \n"
         +"3 - Display employee age \n"
         +"4 - Display all employees \n"
         +"5 - Quit")



hr = employee.HR()

printMenu()
cmd=''
while True:
    cmd = input("Input a command: ")
    if cmd not in ["1","2","3","4","5"]:
        print("Invalid Command.")
        
    elif cmd == "1":
        hr.add_employees()
        
    elif cmd == "2":
        hr.display_employee_salary()

    elif cmd == "3":
        name = input("\nWhat is the name of the employee? ")
        while not name.isalpha() or len(name)<2:
            name = input("Invalid Name. What is the name of the employee? ")
                
        age = hr.display_employee_age(name)
        if age == False:
            print("The employee doesn't exist in the directory! ")
        else:
            print("The employee",name, "is", str(age), "years old! ")            

    elif cmd == "4":
        hr.display_all_employees()
        
    elif cmd == "5":
        break
    printMenu()
input("\nPress Enter key to exit.")
