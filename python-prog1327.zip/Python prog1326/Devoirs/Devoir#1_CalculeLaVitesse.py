#devoir 1
print("Devoir 1 - Calcule La Vitesse par Mario Gauvin\n")
distance = 19.7
temps = 6.892

vitesse = distance/temps
print("vitesse = ", vitesse, "m/s\n")

temps = float(input("Entrer le temps: "))
distance = float(input("Entrer la distance: "))

vitesse = distance/temps
print("\nvitesse = ", vitesse, "m/s")

input("\nPress Enter key to exit")
