class Student():
    def __init__(self):
        self.studentName = ""
        self.grade = ""

class Course():
    def __init__(self):
        self.courseName = ""
        self.students = []

    def add_students(self):
        while True:
            name = input("Quel est le nom de l'étudiant(e)? ")
            while not name.isalpha():
                name = input("Nom invalide. Quel est le nom de l'étudiant(e)? ")

            grade = input("Quel est sa moyenne? ")
            while not grade.replace(".","").isdigit():
                grade = input("Moyenne invalide. Quel est sa moyenne? ")
            while not (0 < float(grade) < 100):
                grade = input("Moyenne invalide. Quel est sa moyenne? ")
                
            myStudent = Student()
            myStudent.studentName = name
            myStudent.grade = float(grade)
            self.students.append(myStudent)
            
            cmd = input("\nVoulez-vous entrer un autre étudiant(e)? (o ou n)")
            if cmd.upper() != "O":
                break
            
    def return_course_average(self):
        if len(self.students) > 0:
            total = 0
            for i in self.students:
                total+= i.grade
            average = total/len(self.students)
            print("\nLa moyenne du cours", self.courseName,"est de : %.1f"%( average))
        else:
            print("Il n’y a pas d’étudiants dans le cours!")


    def return_student_average(self):
        name = input("\nEntrez le nom de l'étudiant(e): ")
        for i in self.students:
            if name.upper() == i.studentName.upper():
                print("\nLa moyenne de cet étudiant(e) est de : %.1f"%( i.grade))
                break

        else:
            print("\nL'étudiant(e) n'est pas inscrit à ce cours.")

    def return_all_students(self):
        if len(self.students) > 0:
            print("\nVoici la liste d'étudiant(e)s du cours")
            for i in self.students:
               print(i.studentName, "%.1f"%( i.grade))
        else:
            print("\nIl n’y a pas d’étudiants dans le cours!")













        
