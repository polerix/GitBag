s = []
resultCount = 0
for i in range(2000,3200):
    if(i%7==0 and i%5!=0):
        s.append(str(i))
        resultCount+=1
patente = ','
print("Devoir 2 Script 1 par Mario Gauvin")
print("Script pour déterminer si tous les nombres entre"
      +"2000 et 3200 qui sont divisible par 7 "
      +"mais qui ne sont pas un multiple de 5.")
print(patente.join(s))
print("Le programme a trouvé:",resultCount,"nombre répondant au critère")
input("Appuyer la touche Enter pour sortir.")

