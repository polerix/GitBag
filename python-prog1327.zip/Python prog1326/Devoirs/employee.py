class Employee():
    def __init__(self):
        self.name = ""
        self.birthYear = ""
        self.rate = 0.00

class HR():
    def __init__(self):
        self.employees = []

    def add_employees(self):
        while True:
            name = input("\nWhat is the name of the employee? ")
            while not name.isalpha() or len(name)<2:
                name = input("Invalid Name. What is the name of the employee? ")
                    
            year = input("\nWhat is his/her year of birth(YYYY)? ")
            while not year.isdigit() or len(year) != 4:
                year = input("Invalid Year of Birth. What is his/her year of birth(YYYY)? ")
                    
            try:
                hourlyRate = float(input("\nWhat is his/her hourly rate ($/h) ?"))
                while  hourlyRate <=0 :
                    hourlyRate = float(input("Invalid Rate. What is his/her hourly rate ($/h)? "))
            except ValueError:
                hourlyRate = float(input("Invalid Rate. What is his/her hourly rate ($/h)? " ))
             

            myEmployee = Employee()
            myEmployee.name = name
            myEmployee.birthYear = int(year)
            myEmployee.rate = float(hourlyRate)
            self.employees.append(myEmployee)
            
            cmd = input("\nDo you want to enter another employee? (y or Y) ")
            if cmd.upper() != "Y":
                break
            
    def display_employee_age(self, name):
        import time
        for i in self.employees:
            if name.upper() == i.name.upper():
                return str(int(time.strftime("%Y"))- i.birthYear)
                break

        else:
            return False 

    def display_employee_salary(self):
        name = input("Which employee are you looking for? ")
        while not name.isalpha() or len(name)<2:
            name = input("Invalid Name. Which employee are you looking for? ")
        for i in self.employees:
            if name.upper() == i.name.upper():
                try:
                    hours = float(input("How many hours did he/she worked this week? "))
                    while not (0 < float(hours) < 168):
                        hours = float(input("Invalid number of hours. How many hours work hours for the employee? "))                  
                        
                except ValueError:
                    hours = float(input("Invalid Rate. What is his/her hourly rate ($/h)? " ))
                    
            salary = float(i.rate) * hours
            print("The salary of",i.name, "at", str(hours),"h is $%.2f" %(salary))
            break
        else:
            print("The employee doesn't exist in the directory!")

    def display_all_employees(self):
        if len(self.employees) > 0:
            print("\nHere is the list of employees contained in the directory:")
            count = 1
            for i in self.employees:
               print("Employee(%d) - Name:"%(count),i.name+ ", YoB:",i.birthYear,"Age:",self.display_employee_age(i.name),",HourlyRate:%.2f "%(i.rate) )
               count+=1
        else:
            print("\nIl n’y a pas d’étudiants dans le cours!")













        
