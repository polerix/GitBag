students = ["yo","dude","bro"]
grade = [25,50,75]
if len(students) > 0:
        total = 0
        for i in students:
            total+=grade[i]
        average = total/len(students)
        print("La moyenne du cours est de :%.1f",average)
