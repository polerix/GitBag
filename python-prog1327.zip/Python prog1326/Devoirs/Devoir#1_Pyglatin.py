#devoir 1
print("Devoir 1 - Pyglatin par Mario Gauvin\n")

word=input("Entrer un mot: ")

while not word.isalpha():
    print("\nCe n'est pas un mot!")
    word=input("\nEntrer un mot: ")
    
if (word[0] == 'a' or word[0] =='e'
    or word[0] =='i' or word[0] =='o' or word[0] =='u'):
    
    j = word[2:] + word[0:2] + 'ay'
    
else:
    j = word[1:] + word[0] + 'ay'
    
print(j)
    
input("\nPress Enter key to exit")
