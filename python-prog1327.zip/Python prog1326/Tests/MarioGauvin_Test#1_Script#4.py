print("Test 1 Script 4 par Mario Gauvin")
print("Script pour l'addition d'entier positif en boucle")

counter = 1
somme = 0
while counter <5:
    num = input("\nEntrer un entier positif (%d): " %(counter))
    while not num.isdigit():
        print("Ce nombre n'est pas un entier positif!")
        num = input("Entrer un entier positif (%d): " %(counter))
    counter+=1
    somme += int(num)

print("La somme des nombres entrés est:", somme)
input("\nAppuyer la touche Enter pour sortir")
