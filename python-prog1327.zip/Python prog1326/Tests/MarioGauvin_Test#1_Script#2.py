print("Test 1 Script 2 par Mario Gauvin")
print("Script pour déterminer la longueur d'un mot et afficher les lettres du mot.")

word=input("S.V.P. Entrer un mot: ")
while not word.isalpha():
    print("\nVous n'avez pas entré un mot!")
    word=input("S.V.P. Entrer un mot: ")
    while len(word)<2:
        print("\nVous n'avez pas entré un mot!")
        word=input("S.V.P. Entrer un mot: ")

    
print("la longueur du mot est:",len(word))
print("Votre mot s'épelle:")
for i in word:
    print(i)

input("Appuyer la touche Enter pour sortir")
