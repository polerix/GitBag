print("Test 1 Script 3 par Mario Gauvin")
print("Script pour calculer la distance (D=V*t), la vitesse (V=D/t) ou le temps (t = D/V).")

def printMenu():
    print(
         "1 - Calculer la distance (m) \n"
         +"2 - Calculer la vitesse (m/s) \n"
         +"3 - Calculer le temps (s) \n"
         +"4 - sortir")

printMenu()
cmd=''
while True:
    cmd = input("choisir un calcul: ")
    if cmd not in ["1","2","3","4"]:
        print("\nEntrée invalide!\n")
        
    elif cmd == "1":        
        vitesse = input("\nEntrer la vitesse: ")
        while not vitesse.lstrip('-').replace(".","").isdigit():
            print("La vitesse doit être une valeur flottante!")
            vitesse = input("Entrer la vitesse: ")
        
        temps = input("Entrer le temps: ")
        while not temps.replace(".","").isdigit():
            print("Le temps doit être une valeur flottante!")
            temps = input("Entrer le temps: ")
            
        distance = float(vitesse)*float(temps)
        print("\nLa distance est: %.2f"%( distance)+" m\n")
        
    elif cmd == "2":
        temps = input("\nEntrer le temps: ")
        while not temps.replace(".","").isdigit():
            print("Le temps doit être une valeur flottante!")
            temps = input("Entrer le temps: ")
            
        distance = input("Entrer la distance: ")
        while not distance.replace(".","").isdigit():
            print("La distance doit être une valeur flottante!")
            distance = input("Entrer la distance: ")
            
        vitesse = float(distance)/float(temps)
        print("\nLa vitesse est: %.2f"%( vitesse)+" m/s\n")
        
    elif cmd == "3":
        vitesse = input("\nEntrer la vitesse: ")
        while not vitesse.lstrip('-').replace(".","").isdigit():
            print("La vitesse doit être une valeur flottante!")
            vitesse = input("Entrer la vitesse: ")

        distance = input("Entrer la distance: ")
        while not distance.replace(".","").isdigit():
            print("La distance doit être une valeur flottante!")
            distance = input("Entrer la distance: ")

        temps = float(distance)/float(vitesse)
        print("\nLe temps est: %.2f"%( temps)+" s\n")
        
    elif cmd == "4":
        break
    printMenu()



input("\nAppuyer la touche Enter pour sortir")
