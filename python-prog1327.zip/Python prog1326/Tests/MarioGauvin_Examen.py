import calculator

def printMenu():
    print(
        "\n------------------------------\n"
        +"Operations available\n"
        +"1 - Add\n"
        +"2 - Divide\n"
        +"3 - Multiply\n"
        +"4 - Show last total\n"
        +"5 - Add numbers to the list\n"
        +"6 - Print the list\n"
        +"7 - Clear list\n"
        +"8 - Exit")


print("Examen de Python par Mario Gauvin")
print("Command Line Calculator\n")

ops = {1:"Addition", 2:"Division", 3:"Multiplication"}

myCalc = calculator.Calculator()
myCalc.inputNumbers()
printMenu()

cmd=''
while True:
    valid = False
    cmd = input("Input a command: ")
    while not valid:        
        if cmd not in ["1","2","3","4","5","6","7","8"]:
            cmd = input("Invalid Command. New Command:")
        else:
            valid = True
    if cmd == "1":
        result = myCalc.calculate(ops.get(1))
        print("\nThe result of",ops.get(1), "is",result)
        
    elif cmd == "2":
        result = myCalc.calculate(ops.get(2))
        print("\nThe result of",ops.get(2), "is",result)

    elif cmd == "3":
        result = myCalc.calculate(ops.get(3))
        print("\nThe result of",ops.get(3), "is",result)

    elif cmd == "4":
        print("\nThe last total was:",myCalc.total)

    elif cmd == "5":
        myCalc.inputNumbers()
        
    elif cmd == "6":
        if len(myCalc.numbers)<=0:
            print("\nYour list is empty!")
        else:
            print("\nHere is your list:",myCalc.numbers)       
        
    elif cmd == "7":
        myCalc.numbers = []
        print("\nThe list is now empty!")
        
    elif cmd == "8":
        break
    printMenu()
    
input("\nPress Enter Key to Exit.")
