class Calculator:
#La méthode init contient une liste numbers et total initialisé à 0.0
    def __init__(self):
        self.numbers = []
        self.total = 0

#Créer la méthode inputNumbers
    def inputNumbers(self):
        while True:
            num = input("Add a positive float to the list: ")
            while True:            
                try:                
                    if float(num) <= 0:
                        num = input("Invalid number. Try again: ")   
                    else:                    
                        break                                     
                except ValueError:                    
                    num = input("Invalid number. Try again: ")
                    
            self.numbers.append(num)
            cmd = input("Do you want to add another number? (y or Y):")            
            if cmd.lower() != 'y' and len(self.numbers) >= 2:
                break
            else:
                print("You need at least 2 numbers in the list")

#Créer la méthode calculate qui prend une opération en paramètre.
    def calculate(self, op):
        self.total=0
        if op not in ["Addition","Division","Multiplication"]:
            print("command not found.")
        elif op == "Addition":
            for n in self.numbers:
                self.total += float(n)
            return self.total
                
        elif op == "Division":
            div = input("\nWhich number do you want to divide by: ")
            while True:
                try:
                    if float(div) >= 0:
                        break
                    else:
                        div = input("Invalid number. Try again: ")
                        
                except ValueError:
                    div = input("Invalid number. Try again: ")

            try:
                self.total=float(self.numbers[0])
                for n in self.numbers:                  
                    self.total /= float(n)
                self.total/float(div)
            except ZeroDivisionError:
                return print("Can't Divide by 0!")                
            return self.total
            
        elif op == "Multiplication":
            self.total=1
            for n in self.numbers:
                self.total *= float(n)
            return self.total    

#Exemple si ma liste contient 3 nombres [25.0, 5.0, 2.0]
#Addition: 25.0+5.0+2.0 la fonction retournera 32.0
#Multiplication: 25.0*5.0*2.0 la fonction retournera 250.0
#Division: 25.0+5.0+2.0 diviser par le nombre demandé.
#Utiliser le try except avec la division pour ne pas avoir d'erreur (ZeroDivisionError)
#Si le diviseur est 0 la méthode doit retourner
#Can't divide by 0!

