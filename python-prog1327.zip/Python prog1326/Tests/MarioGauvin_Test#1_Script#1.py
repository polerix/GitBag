print("Test 1 Script 1 par Mario Gauvin")
print("Script pour déterminer si un mot comence par une consonne ou une voyelle(aeiouy)")

word=input("S.V.P. Entrer un mot: ")
while not word.isalpha():
    print("\nVous n'avez pas entré un mot!")
    word=input("S.V.P. Entrer un mot: ")
    while len(word)<2:
        print("\nVous n'avez pas entré un mot!")
        word=input("S.V.P. Entrer un mot: ")

if word[0].lower() not in ["a","e","i","o","u","y"]:
    print("Votre mot commence par la consonne:", word[0])
else:
    print("Votre mot commence par la voyelle:", word[0])

input("Appuyer la touche Enter pour sortir")
