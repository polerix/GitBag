# HashtagTeamParleMal Mario Sean Robby

from tkinter import *
from tkinter.messagebox import *

class Calculator():
    def __init__(self):
        self.total = 0 #Retient ou le total des opérations est rendu
        self.current = 0 #Contient le contenu de l'écran d'affichage
        self.new_num = True #Recommence le nombre
        self.op_pending = False #Si il y a une opération en attente
        self.op = "" #Opération à effectuer
        self.eq = False #Lorsque la touche égale est appuyée.

#Fonction pour afficher les chiffres à l'écran
    def num_press(self, num):
        self.eq = False
        temp = text_display.get()
        temp2 = str(num)      
        if self.new_num:
            self.current = temp2
            self.new_num = False
        else:
            if temp2 == '.':
                if temp2 in temp:
                    return
            self.current = temp + temp2
        self.display(self.current)

#Fonction pour la touche Égale
    def calc_total(self):
        self.eq = True
        self.current = float(self.current)
        self.do_sum()
        if not self.op_pending:
            self.total = float(text_display.get())

#Fonction pour afficher à l'écran
    def display(self, value):
        text_display.delete(0,END)
        text_display.insert(0,value)
        
#Fonction pour calculer
#Une division par 0 devrait montrer un message d'erreur "Can't Divide by 0."
    def do_sum(self):
                
        if self.op == "plus":
            self.total +=  float(self.current)
            
        if self.op == "moin":
            self.total -= float(self.current)
            
        if self.op == "mult":
            self.total *= float(self.current)
            
        if self.op == "div":
            try:
                self.total /= float(self.current)
            except ZeroDivisionError:
                showerror("Error", "Can't divide by 0.")
        
        self.op_pending = False
        self.new_num = True
        self.display(self.total)
        
#Fonction pour storer l'opération
    def operation(self, op): 
        self.current = float(self.current)
        if self.op_pending:
            self.do_sum()
        elif not self.eq:
            self.current = self.total 
            
        self.new_num = True
        self.op_pending = True
        self.op = op
        self.eq = False

#Fonction pour canceller (Touche A/C)
    def all_cancel(self):
        self.total = 0 
        self.current = 0 
        self.new_num = True 
        self.op_pending = False 
        self.op = "" 
        self.eq = False
        self.display(0)
        
#Fonction pour les pourcentages
    def calc_percent(self):
            
        if self.total==0:
            self.total = 1.0
        self.total *= (float(self.current)/100)
        self.display(self.total)

#Fonction pour changer les nombres en positifs et négatifs
    def sign(self):
        if str(self.current).startswith('-'):
            self.current = abs(float(self.current))
        else:
            self.current = float(self.current ) * -1
        self.display(self.current)
        
#Déclaration de mon application "Calculator"
myCalc = Calculator()
root = Tk()
root.title("Calculator")
root.geometry("190x315")
calc = Frame(root)
calc.grid()


#Déclaration du textbox
text_display = Entry(calc, bg="white", justify=RIGHT)
text_display.grid(row=0,pady = 2,padx = 20,column=0,columnspan = 4, sticky=N+S+E+W)
text_display.insert(0,"0")

#Déclaration des boutons
#Le sigle de division ÷ est le suivant chr(247)
#Lorsque le bouton est une opération vous devez appeller la fonction approprié.
#nums=[7:0, 8:1, 9:2, 4:0, 5:1, 6:2, 1:0,2:1 ,3:2]
nums="789456123"
i=0      
for n in range(2,5):
        for s in range(3):
            bttn = Button(calc, text = nums[i], height = 3, width = 5)
            bttn["command"] = lambda x = nums[i]: myCalc.num_press(x)
            bttn.grid(row = n, column = s, columnspan = 1, pady = 1, sticky=N+S+E+W)
            i+=1
root.mainloop()

