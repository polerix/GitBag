class User:
    def __init__(self):
        self.name=""
        self.password=""

    def checkPassword(self,password):
        if password == self.password:
            print("Access Granted you all G")
        else:
            print("Chiss tu croi que T aaaanyways avec le wrong password va ten.")
