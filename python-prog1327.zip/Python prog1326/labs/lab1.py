#lab1
#question 1
print("sup world")

#question 2
print("enter your name:")
name = input()
print("sup "+ name +"\n")

#question 3
print("enter 2 numbers")
firstNumber= int(input())
secondNumber= int(input())
print(firstNumber + secondNumber)

#question 4
import time
print("what year were you born? ")
birthYear = int(input())
print("your age is:",str(int(time.strftime("%Y"))- birthYear))

#question 5
import math
print("enter x coordinate")
x1= int(input())
x2= int(input())
print("enter y coordinate")
y1= int(input())
y2= int(input())

distance = math.sqrt(math.pow(x1-x2,2) + math.pow(y1-y2,2))
print("the distance between these coordinates is:",distance)
