#lab3 ou deux maybe

###question1
##import math
##
##floatyNumber = float(input("enter a float: "))
##if floatyNumber >= 0:
##    print("the square root is: ", math.sqrt(floatyNumber))
##else:
##    print("error")

###question 2
##word1=input("enter a silly word: ")
##word2=input("enter another silly word: ")
##if word1<word2:
##    print(word1 + " is shorter than " + word2)
##else:
##    print(word1 + " is longer than " + word2)

###question3
##pThreshold = 2.3
##vThreshold = 7.41
##pressure = float(input("enter a pressure: "))
##volume = float(input("enter a volume: "))
##if pressure>pThreshold and volume>vThreshold:
##    print("STAAHP")
##    
##elif pressure > pThreshold:
##    print("increase the volume")
##    
##elif volume > vThreshold:
##    print("drop the volume")
##    
##else:
##    print("its all G")
##    

###question4
##a=0
##b=10
##while a<b:
##    a = a+1
##    print(a)
##
##a=0
##b=10
##while b>0:
##    b = b-1
##    if b%2!=0:
##        print(b)
##    
###question5
##
##while True:
##    number = int(input("enter a number between 1 and 10: "))
##    if number >= 1 and number <= 10:
##        print("your number is: ",number)
##        break
##    else:
##        print("wrong value dude")


###question 6
##word = input("enter a word: ")
##for l in word:
##    print(l)


###question 7
##
##for i in range(1,15,3):
##    print(i)

###question 8
##
##for i in range(1,11):
##    if i == 5:
##        print("break",i)
##        break
##    else:
##        print(i)

###question 9
##
##for i in range(1,11):
##    if i == 5:
##        print("continue",i)
##        continue
##    else:
##        print(i)


###question 10
##import math
##for i in range(-3,4):
##    try:
##        print(math.sin(i)/i)
##    except ZeroDivisionError:
##        print("cannot divide by 0.")
##
##































    
