import User
user = User.User()
name = input("coss quest le user name? ")
while True:
    if name.isalpha() and len(name) > 0:
        user.name = name
        break
    else:
        name = input("Nom invalide. coss quest le user name? ")
import getpass      
password1 = getpass.getpass("enter Password: ")
password2 = getpass.getpass("Re-Enter Password: ")

while password1 != password2:
    password2 = getpass.getpass("password Incorect Bro enter le password again: ")

user.password = password1
user.checkPassword(password1)
