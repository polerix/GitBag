from tkinter import *
def validatePass():
    valid="You have access to something special."
    invalid="Access Denied yo"
    if password.get() == "password":
        text.delete(0.0,END)
        text.insert(0.0,valid)
    else:
        text.delete(0.0,END)
        text.insert(END,invalid)
        
login = Tk()
login.title("login")
login.geometry("285x160")
label = Label(login, text="Enter the password").grid(row=0,column=0, sticky=W)


password = Entry(login, bg="white")
password.grid(row=0,column=1, sticky=E)

text = Text(login, height=4,width=35, wrap=WORD)
text.grid(row=2,column=0,columnspan=2)

submit = Button(login, text="submit", fg="black", command=validatePass)
submit.grid(row=1,column=1,sticky=E)

QUIT = Button(login, text="QUIT", fg="red", command=login.destroy).grid(row=3,column=0,columnspan=2, sticky=N+E+W+S)



login.mainloop()


