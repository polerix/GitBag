# liste 1
liste=[17,38,10,25,72]
liste.sort()
print(liste)

liste.reverse()
print(liste)

print(liste.index(17))

liste.pop(liste.index(38))
print(liste)
print(liste[1:3])
print(liste[0:2])
print(liste[2:])
print(liste[:])
print(liste[-1])

#liste 2
words=input("type in some words:")
wordList=words.split()
wordList.sort()
word=''
for w in wordList:
    word+=w+' '
    
print(word)

#tuple 1
tup = (1,2,3,4,5,6,7,8,9,10)
print(tup[0:5])
print(tup[5:11])

#tuple 2
tuplist=[]
tup2=()
for i in tup:
    if i%2==0:
        tuplist.append(i)
tup2=tuple(tuplist)
print(tup2)

#dictionaire 1
dictionaire={}
number = int(input("enter a nombre entier yo:"))
i=1
while i < number+1:
    dictionaire[i]=i*i
    i+=1

print(dictionaire)

#dictionaire2
def wordThing(string):
    dictionaire2={}
    ball=string.split()
    for s in ball:
        if s not in dictionaire2.keys():
            dictionaire2[s] = 1
        else:
            dictionaire2[s] += 1
    return dictionaire2

string = "Ala Met Asn Glu Met Cys Asn Glu Hou Ala Met Gli Asn Asn"
bla=wordThing(string)
for i in bla.keys():    
    print(i,"-->",bla.get(i) )






