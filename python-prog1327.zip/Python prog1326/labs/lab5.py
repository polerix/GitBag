class User(object):
    def __init__(self):
        self.nom = "Mario"
        self.ville = "Dieppe"
        self.phone = "506-225-1957"


plaise = User()
print(plaise.nom)
print(plaise.ville)
print(plaise.phone)

plaise.nom = "dose"
print(plaise.nom)
def printMenu(s):
   s = print(
         "\nQue voulez-vous faire?\n"
         +"1 - Aficher \n"
         +"2 - Modifier \n"
         +"a - le nom \n"
         +"b - la ville \n"
         +"c - la phone \n"
         +"m - Aficher le menu \n"
         +"3 - Aficher l'utilisateur \n"
         +"4 - sortir \n")
   return s

a=''
print(printMenu(a))

choice=''
while True:
 
    choice=input("comande:")
    
    if len(choice)>2:
        print("commande incorecte yo!")
        
    elif choice == '4':
        print("aurevoir dude!")
        break
    
    elif choice == '1a':
        print(plaise.nom)
        continue
    
    elif choice == '1b':
        print(plaise.ville)
        continue
    
    elif choice == '1c':
        print(plaise.phone)
        continue
    
    elif choice == '2a':
        plaise.nom=input("quelle est le nouveau nom? ")
        continue
    
    elif choice == '2b':
        plaise.ville=input("quelle est la nouvelle ville? ")
        continue
    
    elif choice == '2c':
        plaise.phone=input("quelle est le new phone number? ")
        continue
    
    elif choice == '3':
        print("voici linfo su le user")
        print("nom: ",plaise.nom)
        print("ville: ",plaise.ville)
        print("phone: ",plaise.phone)
        continue
    elif choice == 'm':
        print(printMenu(a))
        continue
    
    else:
        print("commande incorecte yo!")
print("done")
