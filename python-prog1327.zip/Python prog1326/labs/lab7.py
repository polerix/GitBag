print("entrer 2 entiers.")
try:
    num1 = int(input("Quel est le premier chiffres: "))
    while  num1 <=0 :
        num1 = int(input("votre chiffres doit etre plus grand que 0 "))
except ValueError:
    num1 = int(input("un votre chiffre est mauvais recommencer.  " ))
    
try:
    num2 = int(input("\nQuel est le deuxieme chiffres: "))
    while  num2 <=0 :
        num2 = int(input("votre chiffres doit etre plus grand que 0 "))
except ValueError:
    num2 = int(input("un votre chiffre est mauvais recommencer.  " ))
print("\nL'addition de vos chiffres donne: (%d)" %(num1+num2))
input("\nAppuyer la touche Enter pour sortir.")
