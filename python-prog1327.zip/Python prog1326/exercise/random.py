import random
randomNumber = random.randrange(1,11)
print("guess the corect number or press q to quit")
count=1
while True:
    while True:
        try:
            guess = input("enter a number between 1 and 10: ")
            if (guess == 'q') or (int(guess) >= 1 and int(guess) <= 10):
                break
        except ValueError:
            if guess != 'q':
                print("wrong choice buddy. guess again")


    if (guess == 'q'):
        break
    elif (int(guess) < randomNumber):
        print("too low ")
        count+=1
    elif (int(guess) > randomNumber):
        print("too high ")
        count+=1
    else:
        print("your guess is correct")
        print("you got it in ", count, "guess.")
        break
print("done")

##
##x=[4,6,7,9,10,11,15,19,23,24]
##y=[1,3,5,7,9,11,13,15,17,19,21,23,25]
##z=[]
##for i in x:
##    for i2 in y:
##        if (i==i2):
##            z.append(i2)
##            print(i2)
##print(z)

##words = input("enter chek mots: ")
##print(words)
##wordd = words.split()
##wordd.reverse()
##d=''
##for s in wordd:
##    d+=s+' ';
##print(d)

