def forLoopPatente(n):
    liste= []
    for i in range(n):
        liste.append(12*i+1)
    return liste

x=forLoopPatente(10)
print(x)

def listeComprehension(n):
    liste = [12*i+1 for i in range(n)]
    return liste

y=listeComprehension(10)
print(y)

from time import clock
def duree(function, n=1000000):
    start=clock()
    function(n)
    end=clock()
    return end - start

meh=duree(forLoopPatente)
print("time length using for loop",meh)
meh=duree(listeComprehension)
print("time length using for loop comprehension",meh)
