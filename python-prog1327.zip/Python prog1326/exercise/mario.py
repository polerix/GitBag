mario = {1 :'mario ',2: 'dollard ' , 3: 'gauvin ', 4: '21 ', 5: 'dose ',
         6:'tamere@gmail.com '}

print(mario[1]+mario[2]+mario[3]+mario[4]+mario[5])
print(mario[6])
for i in mario:
    print(mario[i])
    
s = "spam"
print("actual valus",s)
g = s[0:1] + "l" + s[2:4]
print("truncated",g)
f = s[0]+ "l" + s[2] + s[3]
print("fukn indexs",f)
r = s.replace("p", "ball")
print("string.replaceFunctio",r)
