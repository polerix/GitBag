d=''
asciiList = []
for s in range(1,257):
    d+= chr(s)
    asciiList.append(format(s,'b'))
    print(chr(s))
print(d)
print(asciiList)

lint=[]
lchar=[]
dic={}
word='fuckin patate masher yo'
for s in word:
    print(ord(s))
    lint.append(ord(s))
    lchar.append(s)
    dic[s]=ord(s)
print(lint)
print(lchar)
print(dic)

somme=0
for i in lint:
    somme+=i
print(somme)

bla=[]
bla=list(dic.keys())
print(bla)
bla.sort()
print(bla)

for i in bla:
    print(dic.get(i))

